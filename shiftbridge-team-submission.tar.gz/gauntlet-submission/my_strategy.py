"""Competitor strategy definition for starter-kit agents.

Optimized for higher reliability, robust parsing, exact format compliance,
and smart model/tool sequencing.
"""

from __future__ import annotations

import re
from typing import Any

from base_strategy import BaseStrategy, ChallengeContext


class MyStrategy(BaseStrategy):
    """ShiftBridge — high-performance strategy for Agent Gauntlet."""

    # Team identity
    agent_id = "shiftbridge-team"
    agent_name = "ShiftBridge"

    # Give reasoning models room to think while keeping responses deterministic.
    text_max_tokens = 8192
    text_temperature = 0.0

    # ---- prompts ---------------------------------------------------------
    text_system_prompt = (
        "You are an expert puzzle and challenge solver competing in Agent Gauntlet. "
        "Your FIRST line must be exactly: ANSWER: <final answer>. "
        "Follow challenge rules exactly, especially formatting constraints (e.g., comma-separated lists, "
        "exact casing, specific key orders, or tuple shapes). "
        "Do not output <think> or <toolcall> tags. Never output 'unknown'. "
        "Do not wrap your answer in quotes or markdown code blocks unless requested by rules. "
        "If you include reasoning, put at most 2 short lines AFTER the ANSWER line. "
        "Before submitting, call broadcast_thought (POST /api/thought) once "
        "so spectators can follow your progress."
    )

    text_strategy_notes = (
        "Answer-first format: First line MUST be 'ANSWER: <final answer>'. "
        "Strictly adhere to output formatting rules from the challenge prompt."
    )

    image_strategy_notes = (
        "Prefer image_edit when an input image is available to preserve core subject and layout. "
        "Request standard resolution (~1024px) only. Avoid HD, 4K, upscaling, or extra text."
    )

    # Known preferred reasoning models when available on the proxy.
    # Priority order balances deep reasoning quality and speed.
    _REASONING_PRIORITY = (
        "gemini-3.8-flash",
        "gemini-3.7-flash",
        "gemini-3.6-flash",
        "qwen3.7-plus",
        "qwen3.7-flash",
        "qwen3.7-max",
        "gpt-5.4",
        "gpt-5.6-terra",
        "qwen3.6-35b",
        "nemotron-3-ultra",
        "nemotron-3-super",
    )

    # Preferred reasoning models for easy tasks.
    # Gemini flash models solve simple puzzles rapidly with high speed and quality.
    _EASY_REASONING_PRIORITY = (
        "gemini-3.7-flash",
        "gemini-3.6-flash",
        "gemini-3.8-flash",
        "qwen3.6-35b",
        "nemotron-3.5-lightning",
        "qwen3.7-plus",
        "nemotron-3-super",
        "qwen3.7-flash",
        "nemotron-3-ultra",
    )

    # Keywords for dynamic tier ranking when model names vary.
    _REASONING_KEYWORDS = (
        "ultra",
        "super",
        "plus",
        "pro",
        "reasoning",
        "qwen",
        "nemotron",
        "claude",
        "gpt-5",
        "gemini",
    )

    _FAST_KEYWORDS = (
        "flash",
        "lightning",
        "mini",
        "lite",
        "turbo",
        "fast",
    )

    @staticmethod
    def is_easy_challenge(ctx: ChallengeContext) -> bool:
        """Check if challenge is classified as easy or has tight time limits indicating a simple task."""
        diff = str(getattr(ctx, "difficulty", "") or "").lower()
        if "easy" in diff:
            return True
        if ctx.max_time_s and ctx.max_time_s <= 60:
            return True
        desc = (ctx.description or "").lower()
        rules = (ctx.rules or "").lower()
        if "easy" in desc or "easy" in rules:
            return True
        return False

    # ---- model selection -------------------------------------------------
    def rank_models(
        self,
        ctx: ChallengeContext,
        available_models: list[str],
    ) -> list[str]:
        """Rank models dynamically based on availability and capability tier."""
        if not available_models:
            return []

        if self.is_image_challenge(ctx):
            # Prefer image-capable models first via base class / model_selector
            image_models = self.prefer_image_models(available_models)
            if image_models:
                # Rank preferred image models (pro/flash image models first)
                ranked_image: list[str] = []
                for kw in ("pro", "flash", "edit", "gen", "image"):
                    for m in image_models:
                        if m not in ranked_image and kw in m.lower():
                            ranked_image.append(m)
                for m in image_models:
                    if m not in ranked_image:
                        ranked_image.append(m)
                return ranked_image
            return super().rank_models(ctx, available_models)

        available = list(available_models)
        ranked: list[str] = []

        # Select priority order based on challenge difficulty
        priority = (
            self._EASY_REASONING_PRIORITY
            if self.is_easy_challenge(ctx)
            else self._REASONING_PRIORITY
        )

        # 1. First check explicit priority list
        for m in priority:
            if m in available and m not in ranked:
                ranked.append(m)

        # 2. Match remaining models by keyword tier
        if self.is_easy_challenge(ctx):
            # Easy challenges: prioritize fast/flash models before heavy reasoning models
            for m in available:
                if m in ranked:
                    continue
                lower_name = m.lower()
                if any(kw in lower_name for kw in self._FAST_KEYWORDS):
                    ranked.append(m)

            for m in available:
                if m in ranked:
                    continue
                lower_name = m.lower()
                if any(kw in lower_name for kw in self._REASONING_KEYWORDS):
                    ranked.append(m)
        else:
            # Standard/hard challenges: prioritize flagship/reasoning models first
            for m in available:
                if m in ranked:
                    continue
                lower_name = m.lower()
                if any(kw in lower_name for kw in self._REASONING_KEYWORDS):
                    ranked.append(m)

            for m in available:
                if m in ranked:
                    continue
                lower_name = m.lower()
                if any(kw in lower_name for kw in self._FAST_KEYWORDS):
                    ranked.append(m)

        # 3. Append any remaining models in original proxy roster order
        for m in available:
            if m not in ranked:
                ranked.append(m)

        return ranked or available

    def pick_model(
        self,
        stage: str,
        ranked_models: list[str],
        ctx: ChallengeContext,
    ) -> str:
        """Choose model based on stage (solve, verify, fast)."""
        if not ranked_models:
            return ""
        if stage in {"verify", "repair"} and len(ranked_models) > 1:
            # Stage verify can use a fast or alternate model if available
            return ranked_models[-1]
        return ranked_models[0]

    # ---- prompt engineering ---------------------------------------------
    def build_system_prompt(self, ctx: ChallengeContext) -> str:
        """Build dynamic system prompt reflecting challenge-specific rules."""
        base_sys = str(self.text_system_prompt).strip()
        rules = (ctx.rules or "").lower()

        extra_rules: list[str] = []
        if "comma-separated" in rules or "comma separated" in rules:
            extra_rules.append(
                "CRITICAL FORMAT RULE: Emit answer as a comma-separated list with no extra spaces or quotes."
            )
        if "exactly one line" in rules or "one line only" in rules:
            extra_rules.append(
                "CRITICAL FORMAT RULE: Output exactly ONE line starting with 'ANSWER: '."
            )
        if "key order" in rules or "template:" in rules:
            extra_rules.append(
                "CRITICAL FORMAT RULE: Respect key order and structural templates defined in rules exactly."
            )

        if self.is_easy_challenge(ctx):
            extra_rules.append(
                "EASY PUZZLE INSTRUCTION: This is a simple puzzle. Keep reasoning extremely short and direct, "
                "solve step-by-step quickly, and output the ANSWER line immediately without spending excessive time thinking."
            )

        if extra_rules:
            return f"{base_sys}\n\n" + "\n".join(extra_rules)
        return base_sys

    def build_solver_prompt(self, ctx: ChallengeContext) -> str:
        """Enhance solver prompt with domain-specific verification rules."""
        base_prompt = super().build_solver_prompt(ctx)
        ctype = ctx.challenge_type.lower()
        rules = (ctx.rules or "").lower()

        reminders: list[str] = []

        if "sequencing" in ctype or "logic" in ctype or "order" in rules:
            reminders.append(
                "Constraint & Logic Verification:\n"
                "- Double-check all relational constraints before finalizing sequence.\n"
                "- Ensure every item listed in clues is accounted for exactly once.\n"
                "- No duplicates unless explicitly allowed."
            )
        if "search" in ctype or "research" in ctype or "web" in ctype:
            reminders.append(
                "Factual & Evidence Verification:\n"
                "- Base your answer strictly on provided search/tool evidence.\n"
                "- Provide exact entity/provider names or values requested by the question."
            )
        if "code" in ctype or "math" in ctype or "calculation" in rules:
            reminders.append(
                "Calculation Verification:\n"
                "- Execute and double-check arithmetic, formula evaluations, and index positions."
            )

        if reminders:
            base_prompt += "\n\n" + "\n\n".join(reminders)

        return base_prompt

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        """Build structured prompt for image challenges."""
        base_img_prompt = super().build_image_prompt(ctx)

        # Add visual fidelity and constraint hints
        quality_hints = (
            "\n\nVisual guidelines:\n"
            "- Ensure single coherent visual composition.\n"
            "- If editing an existing image, maintain key subject identity, geometry, and lighting.\n"
            "- Do not add visible text, logos, or watermarks unless specifically requested."
        )
        return f"{base_img_prompt}{quality_hints}"

    # ---- tool planning ---------------------------------------------------
    def plan_tools(
        self,
        ctx: ChallengeContext,
        available_tools: list[str],
    ) -> list[str]:
        """Prioritize clues, search, execution, and timing tools."""
        if self.is_image_challenge(ctx):
            return list(available_tools)

        preferred = (
            "arena.get_challenge",
            "arena.clues.list",
            "arena.clues.get",
            "arena.web_search",
            "search",
            "code.execute",
            "python.execute",
            "arena.time_remaining",
        )

        ordered: list[str] = []
        for pref in preferred:
            for tool in available_tools:
                if tool not in ordered and (pref in tool or tool in pref):
                    ordered.append(tool)

        for tool in available_tools:
            if tool not in ordered:
                ordered.append(tool)

        return ordered

    def plan_image_tool(
        self,
        ctx: ChallengeContext,
        available_tools: list[str],
    ) -> str:
        """Choose best image tool based on context and availability."""
        if ctx.image_url and "image_edit" in available_tools:
            return "image_edit"
        if "image_generate" in available_tools:
            return "image_generate"
        if ctx.image_url and "image_analyze" in available_tools:
            return "image_analyze"
        return available_tools[0] if available_tools else ""

    # ---- safety nets & parsing ------------------------------------------
    def should_submit_early(self, answer: str, ctx: ChallengeContext) -> bool:
        """Submit early once a valid, rule-compliant answer is ready."""
        if not answer or not isinstance(answer, str):
            return False

        stripped = answer.strip()

        # Remove markdown code fences if present
        if stripped.startswith("```"):
            lines = stripped.splitlines()
            if len(lines) > 2:
                stripped = "\n".join(lines[1:-1]).strip()

        if not stripped or stripped.lower() in {"unknown", "none", "null"}:
            return False

        first_line = stripped.splitlines()[0].strip()
        if first_line.upper().startswith("ANSWER:"):
            payload = first_line.split(":", 1)[1].strip()
        else:
            payload = first_line

        payload = payload.strip("`\"'")
        if not payload or payload.lower() in {"unknown", "none", "<final answer>"}:
            return False

        # Reject tool call or xml trace candidates
        if any(bad in payload.lower() for bad in ("<toolcall", "<think", "</think>", "function_call")):
            return False

        return True

    def on_time_warning(
        self,
        remaining_s: float,
        current_answer: str,
        ctx: ChallengeContext,
    ) -> str | None:
        """Near timeout, force a clean, rule-compliant answer payload."""
        if not current_answer or not str(current_answer).strip():
            return None

        stripped = str(current_answer).strip()

        # Clean markdown wrappers
        if stripped.startswith("```"):
            lines = stripped.splitlines()
            if len(lines) > 2:
                stripped = "\n".join(lines[1:-1]).strip()

        # Strip think tags if present
        cleaned = re.sub(r"<think>.*?(?:</think>|$)", "", stripped, flags=re.DOTALL).strip()
        if not cleaned:
            cleaned = stripped

        first_line = cleaned.splitlines()[0].strip()
        if first_line.upper().startswith("ANSWER:"):
            cleaned = first_line.split(":", 1)[1].strip()
        else:
            cleaned = first_line

        cleaned = cleaned.strip("`\"'")
        return cleaned or None

    # ---- thought broadcast ----------------------------------------------
    def on_tool_result(
        self,
        tool_name: str,
        result: dict[str, Any] | Any,
        ctx: ChallengeContext,
    ) -> str | None:
        """Emit progress thoughts after key tool operations for spectator tracking."""
        name_lower = str(tool_name).lower()

        if "clues" in name_lower:
            try:
                count = len(result) if hasattr(result, "__len__") else 0
            except Exception:
                count = 0
            return f"Collected challenge clues ({count}); analyzing constraints."
        elif "code" in name_lower or "python" in name_lower:
            return "Executed code verification script."
        elif "search" in name_lower:
            return "Retrieved search evidence; synthesizing final response."
        elif "get_challenge" in name_lower:
            return "Retrieved core challenge parameters and rules."
        return f"Executed tool `{tool_name}` successfully."
